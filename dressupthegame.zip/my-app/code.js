setScreen("titleScreen");
//group with variables for use in randomize function
var wardrobe = {
  hat: ["","assets/clipshat.png","assets/beaniehat.png"],
  hair: ["","assets/blackhair.png","assets/brownhair.png"],
  face: ["","assets/purpleface.png","assets/glassesface.png"],
  top: ["","assets/yuikigaitop.png","assets/furjackettop.png"],
  bottom: ["","assets/longbottom.png","assets/shortbottom.png"],
  socks: ["","assets/whitesocks.png","assets/blacksocks.png"],
  shoes: ["","assets/sneakersshoes.png","assets/moonbootshoes.png"],
};

//variables for use in next/previous functions
var hat = ["","assets/clipshat.png","assets/beaniehat.png"];
var hair = ["","assets/blackhair.png","assets/brownhair.png"];
var face = ["","assets/purpleface.png","assets/glassesface.png"];
var top = ["","assets/yuikigaitop.png","assets/furjackettop.png"];
var bottom = ["","assets/longbottom.png","assets/shortbottom.png"];
var socks = ["","assets/whitesocks.png","assets/blacksocks.png"];
var shoes = ["","assets/sneakersshoes.png","assets/moonbootshoes.png"];

//variable used to add onto ids that show clothing images
var items = ["Hat","Hair","Face","Top","Bottom","Socks","Shoes"];

//index variables for clothes
var indexHat = 0;
var indexHair = 0;
var indexFace = 0;
var indexTop = 0;
var indexBottom = 0;
var indexSocks = 0;
var indexShoes = 0;

//navigation
//when start is clicked, go to closet screen
onEvent("startButton","click",function(){
  setScreen("closetScreen");
});
//when back is clicked in closet, go to title screen
onEvent("closetBackButton","click",function(){
  setScreen("titleScreen");
});
//when randomize is clicked in closet, go to item selection screen
onEvent("randomizeItemButton","click",function(){
  setScreen("itemSelectionScreen");
});
//when back is clicked in item selection, go to closet screen
onEvent("backSelection","click",function(){
  setScreen("closetScreen");
});
 
//functions to change clothes
//hat next/previous
onEvent("hatNext","click",function(){
  indexHat = nextItem(hat,0,indexHat);
});
onEvent("hatPrevious","click",function(){
  indexHat = previousItem(hat,0,indexHat);
});
//hair next/previous
onEvent("hairNext","click",function(){
  indexHair = nextItem(hair,1,indexHair);
});
onEvent("hairPrevious","click",function(){
  indexHair = previousItem(hair,1,indexHair);
});
//face next/previous
onEvent("faceNext","click",function(){
  indexFace = nextItem(face,2,indexFace);
});
onEvent("facePrevious","click",function(){
  indexFace = previousItem(face,2,indexFace);
});
//top next/previous
onEvent("topNext","click",function(){
  indexTop = nextItem(top,3,indexTop);
});
onEvent("topPrevious","click",function(){
  indexTop = previousItem(top,3,indexTop);
});
//bottom next/previous
onEvent("bottomNext","click",function(){
  indexBottom = nextItem(bottom,4,indexBottom);
});
onEvent("bottomPrevious","click",function(){
  indexBottom = previousItem(bottom,4,indexBottom);
});
//socks next/previous
onEvent("socksNext","click",function(){
  indexSocks = nextItem(socks,5,indexSocks);
});
onEvent("socksPrevious","click",function(){
  indexSocks = previousItem(socks,5,indexSocks);
});
//shoes next/previous
onEvent("shoesNext","click",function(){
  indexShoes = nextItem(shoes,6,indexShoes);
});
onEvent("shoesPrevious","click",function(){
  indexShoes = previousItem(shoes,6,indexShoes);
});
//randomize clothing based on what the user selects
onEvent("submitRandom","click",function(){
  randomize(wardrobe);
});

// functions

//go to the next item and set the image to that item
function nextItem(category,itemIndexNumber,itemIndexVariable){
  if (itemIndexVariable < 2){
    itemIndexVariable = itemIndexVariable + 1;
    setProperty("item"+items[itemIndexNumber],"image",category[itemIndexVariable]);
  }
  return itemIndexVariable;
}
//go to the previous item and set the image to that item
function previousItem(category,itemIndexNumber,itemIndexVariable){
  if (itemIndexVariable > 0){
    itemIndexVariable = itemIndexVariable - 1;
    setProperty("item"+items[itemIndexNumber],"image",category[itemIndexVariable]);
  }
  return itemIndexVariable;
}
function randomize(clothesSet){
  for(var i=0;i<items.length;i++){
    if(getChecked("randomizeAll")){
      for(var c=0;c<items.length;c++){
        var category = items[c].toLowerCase();
        var itemList = clothesSet[category];
        var randomIndex = randomNumber(1,itemList.length-1);
        var randomImage = itemList[randomIndex];
        
        setProperty("item"+items[c],"image",randomImage);
      }  
      setScreen("closetScreen");
      return;
    } else if(getChecked("randomize"+items[i])){
      var category2 = items[i].toLowerCase();
      var itemList2 = clothesSet[category2];
      var randomIndex2 = randomNumber(1,itemList2.length-1);
      var randomImage2 = itemList2[randomIndex2];
        
      setProperty("item"+items[i],"image",randomImage2);
        
      setScreen("closetScreen");
      return;
    }
  }
}